#!/bin/bash
# Team-tab UI test against the local Worker. Detach: (setsid nohup ./test/run-ui.sh > /tmp/runui.log 2>&1 &)
set -u
cd "$(dirname "$0")/.."
stop() { pkill -f "wrangler-dist/cli.js dev" 2>/dev/null; pkill -f "workerd-linux-64/bin/workerd" 2>/dev/null; pkill -f "npm exec wrangler" 2>/dev/null; pkill -f "test/uiserver.mjs" 2>/dev/null; sleep 2; }
stop; rm -rf .wrangler/state
npx wrangler d1 migrations apply kitbash-workspace --local >/dev/null 2>&1 || { echo "migration failed"; exit 3; }
(nohup npx wrangler dev --local --port 8787 --ip 127.0.0.1 > /tmp/wrangler.log 2>&1 &)
for i in $(seq 1 45); do sleep 2; curl -s -m 3 http://127.0.0.1:8787/health >/dev/null 2>&1 && break; done
(nohup node test/uiserver.mjs > /tmp/uiserver.log 2>&1 &)
for i in $(seq 1 20); do sleep 1; grep -q ready /tmp/uiserver.log 2>/dev/null && break; done
python3 test/ui.py; RC=$?
stop; exit $RC
