#!/bin/bash
# Full local verification: fresh D1, phase-1 scenario, restart the Worker, phase-2 persistence check.
set -u
cd "$(dirname "$0")/.."
stop() { pkill -f "wrangler-dist/cli.js dev" 2>/dev/null; pkill -f "workerd-linux-64/bin/workerd" 2>/dev/null; pkill -f "npm exec wrangler" 2>/dev/null; sleep 2; }
start() { (nohup npx wrangler dev --local --port 8787 --ip 127.0.0.1 > /tmp/wrangler.log 2>&1 &); for i in $(seq 1 45); do sleep 2; curl -s -m 3 http://127.0.0.1:8787/health >/dev/null 2>&1 && return 0; done; echo "worker did not start"; tail -20 /tmp/wrangler.log; exit 3; }
stop; rm -rf .wrangler/state
npx wrangler d1 migrations apply kitbash-workspace --local >/dev/null 2>&1 || { echo "migration failed"; exit 3; }
start
echo "##### PHASE 1: full scenario on a fresh database"
node test/e2e.mjs; P1=$?
npx wrangler d1 execute kitbash-workspace --local --command "DELETE FROM owner_attempts" >/dev/null 2>&1   # clear the brute-force lockout the test deliberately triggered
echo; echo "##### restarting the Worker process (local D1 + KV state is on disk)"
stop; start
echo "##### PHASE 2: same tokens, same data after restart"
node test/e2e.mjs --phase=verify; P2=$?
echo; echo "phase1 exit=$P1 phase2 exit=$P2"; exit $((P1 + P2))
