// Kitbash Workspace — Cloudflare Worker entry.
// OAuth 2.1 (PKCE, dynamic client registration) is provided by @cloudflare/workers-oauth-provider.
// The consent screen is where the owner decides WHICH agent identity a connection becomes and which
// scopes it gets; that choice is sealed into the access token and can never be supplied by the caller.
import { OAuthProvider, AuthorizationError } from '@cloudflare/workers-oauth-provider';
import { WorkerEntrypoint } from 'cloudflare:workers';
import { handleMcp } from './mcp.js';
import { listAgents, verifyOwnerKey, WsError } from './service.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SCOPE_MAP = { 'workspace:read': 'read', 'workspace:write': 'write' };
const b64e = (o) => btoa(unescape(encodeURIComponent(JSON.stringify(o))));
const b64d = (s) => JSON.parse(decodeURIComponent(escape(atob(s))));

class McpApi extends WorkerEntrypoint {
  async fetch(request) {
    try { return await handleMcp(request, this.env, this.ctx.props); }
    catch (e) { console.error('mcp fatal', e && e.stack || e); return Response.json({ error: 'internal_error' }, { status: 500 }); }
  }
}

const page = (title, body, status = 200) => new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title>
<style>:root{color-scheme:light dark}body{font:16px/1.5 system-ui,sans-serif;max-width:560px;margin:0 auto;padding:24px 16px;background:Canvas;color:CanvasText}
h1{font-size:22px;margin:0 0 4px}.sub{opacity:.7;margin:0 0 20px}fieldset{border:1px solid color-mix(in srgb,CanvasText 25%,transparent);border-radius:10px;margin:0 0 16px;padding:12px 14px}
legend{font-weight:600;padding:0 6px}label{display:block;margin:8px 0}input[type=password],select{width:100%;padding:10px;font:inherit;border-radius:8px;border:1px solid color-mix(in srgb,CanvasText 35%,transparent);background:Canvas;color:CanvasText;box-sizing:border-box}
button{font:inherit;font-weight:600;padding:12px 18px;border-radius:10px;border:0;background:#1f7a57;color:#fff;cursor:pointer}button.no{background:transparent;color:inherit;border:1px solid color-mix(in srgb,CanvasText 35%,transparent)}
.warn{padding:10px 12px;border-radius:8px;background:color-mix(in srgb,orange 22%,transparent);margin:0 0 16px}code{background:color-mix(in srgb,CanvasText 10%,transparent);padding:1px 5px;border-radius:4px;word-break:break-all}.err{color:#c0392b;font-weight:600}</style></head><body>${body}</body></html>`, { status, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-frame-options': 'DENY', 'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'" } });

async function consentForm(env, oauthReq, client, error) {
  const agents = (await listAgents(env)).filter((a) => a.connectable && a.enabled);
  const name = client.clientName || 'Unnamed client';
  const guess = /chatgpt|openai/i.test(name) ? 'chatgpt' : /claude|anthropic/i.test(name) ? 'claude' : '';
  const asked = oauthReq.scope && oauthReq.scope.length ? oauthReq.scope.filter((s) => SCOPE_MAP[s]) : Object.keys(SCOPE_MAP);
  let host = ''; try { host = new URL(oauthReq.redirectUri).host || oauthReq.redirectUri; } catch { host = oauthReq.redirectUri; }
  return page('Connect an agent to Kitbash Workspace', `
    <h1>Connect an agent</h1><p class="sub">Kitbash Workspace</p>
    ${error ? `<p class="err">${esc(error)}</p>` : ''}
    <div class="warn"><b>${esc(name)}</b> wants access. It will return to <code>${esc(host)}</code>. Only continue if you started this connection yourself.</div>
    <form method="post"><input type="hidden" name="state" value="${esc(b64e(oauthReq))}">
      <fieldset><legend>Which agent is this?</legend>
        <select name="actor" required>${agents.map((a) => `<option value="${esc(a.id)}"${a.id === guess ? ' selected' : ''}>${esc(a.name)} (${esc(a.id)})</option>`).join('')}</select>
        <p class="sub" style="margin:8px 0 0">Everything this connection does is recorded under this identity. It cannot change it later.</p></fieldset>
      <fieldset><legend>What may it do?</legend>
        <label><input type="checkbox" name="scope" value="workspace:read" checked> Read files, tasks, messages</label>
        <label><input type="checkbox" name="scope" value="workspace:write"${asked.includes('workspace:write') ? ' checked' : ''}> Write: post messages, create and hand off tasks, edit files it owns or has leased, propose changes</label>
        <p class="sub" style="margin:8px 0 0">Deleting, restoring and approving always need your owner key, whatever you choose here.</p></fieldset>
      <fieldset><legend>Owner key</legend><input type="password" name="owner_key" autocomplete="current-password" required placeholder="Your owner passphrase"></fieldset>
      <button type="submit">Approve</button> <button class="no" type="submit" name="deny" value="1" formnovalidate>Deny</button>
    </form>`);
}

const defaultHandler = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health') {
      const agents = (await listAgents(env)).map((a) => a.id);
      return Response.json({ ok: true, service: 'kitbash-workspace', version: '0.1.0', mcp: `${url.origin}/mcp`, agents, owner_secret_configured: !!env.OWNER_SECRET && String(env.OWNER_SECRET).length >= 8, openai_configured: !!env.OPENAI_API_KEY && !!env.OPENAI_MODEL });
    }
    if (url.pathname === '/') return page('Kitbash Workspace', `<h1>Kitbash Workspace</h1><p class="sub">Shared workspace for Claude, ChatGPT and other agents.</p><p>MCP endpoint: <code>${esc(url.origin)}/mcp</code></p><p>Add it as a custom connector in Claude or ChatGPT. You will be asked to approve the connection here.</p>`);
    if (url.pathname !== '/authorize') return new Response('Not found', { status: 404 });

    let oauthReq;
    try { oauthReq = await env.OAUTH_PROVIDER.parseAuthRequest(request); }
    catch (e) {
      if (!(e instanceof AuthorizationError)) throw e;
      if (!e.redirectUri) return page('Cannot connect', `<h1>Cannot connect</h1><p class="err">${esc(e.description)}</p>`, 400);
      const r = new URL(e.redirectUri); r.searchParams.set('error', e.code); r.searchParams.set('error_description', e.description); if (e.state) r.searchParams.set('state', e.state); if (e.issuer) r.searchParams.set('iss', e.issuer);
      return Response.redirect(r.toString(), 302);
    }
    const client = await env.OAUTH_PROVIDER.lookupClient(oauthReq.clientId);
    if (!client) return page('Cannot connect', '<h1>Unknown client</h1>', 400);
    if (request.method === 'GET') return consentForm(env, oauthReq, client);

    // POST: the form carries the (client-validated-on-completion) request; the owner key is what authorises it.
    const form = await request.formData();
    let sealed; try { sealed = b64d(String(form.get('state') || '')); } catch { return page('Cannot connect', '<h1>Invalid request</h1>', 400); }
    const reqClient = await env.OAUTH_PROVIDER.lookupClient(sealed.clientId);
    if (!reqClient) return page('Cannot connect', '<h1>Unknown client</h1>', 400);
    if (form.get('deny')) { const r = new URL(sealed.redirectUri); r.searchParams.set('error', 'access_denied'); if (sealed.state) r.searchParams.set('state', sealed.state); return Response.redirect(r.toString(), 302); }
    try {
      if (!(await verifyOwnerKey(env, String(form.get('owner_key') || '')))) return consentForm(env, sealed, reqClient, 'Wrong owner key.');
    } catch (e) { if (e instanceof WsError) return consentForm(env, sealed, reqClient, e.message); throw e; }
    const actor = String(form.get('actor') || '');
    const agent = (await listAgents(env)).find((a) => a.id === actor && a.connectable && a.enabled);
    if (!agent) return consentForm(env, sealed, reqClient, 'Choose which agent this connection is.');
    const granted = form.getAll('scope').map(String).filter((s) => SCOPE_MAP[s] && agent.scopes.includes(SCOPE_MAP[s]));
    if (!granted.includes('workspace:read')) return consentForm(env, sealed, reqClient, 'Grant at least read access.');
    const { redirectTo } = await env.OAUTH_PROVIDER.completeAuthorization({
      request: sealed, userId: `owner-${agent.id}`, metadata: { clientName: reqClient.clientName || null, actor: agent.id },
      scope: granted, props: { actor: agent.id, scopes: granted.map((s) => SCOPE_MAP[s]) }
    });
    return Response.redirect(redirectTo, 302);
  }
};

export default new OAuthProvider({
  apiRoute: '/mcp',
  apiHandler: McpApi,
  defaultHandler,
  authorizeEndpoint: '/authorize',
  tokenEndpoint: '/oauth/token',
  clientRegistrationEndpoint: '/oauth/register',
  scopesSupported: ['workspace:read', 'workspace:write'],
  resourceMetadata: { scopes_supported: ['workspace:read', 'workspace:write'], resource_name: 'Kitbash Workspace' }
});
