# Kitbash Workspace

A shared project workspace for Claude, ChatGPT, an embedded OpenAI agent and you, running on Cloudflare Workers + D1.
It is the server side of the **Team** tab in Kitbash. Kitbash itself (Parts, Import, Build, polish, weave) is unchanged.

```
Kitbash page (Team tab) ──mcp capability──▶ ┐
Claude (claude.ai connector) ─────────────▶ │  /mcp  (OAuth 2.1 + PKCE, streamable HTTP)
ChatGPT (custom connector, if your plan allows) ▶ │        │
                                            │  Cloudflare Worker ── D1 (files, revisions, tasks, messages, approvals, audit)
Embedded OpenAI agent  ◀── run_agent ───────┘                 └── KV (OAuth grants)
   (server-side call to the OpenAI API)
```

## Status — read this first

| Thing | State |
|---|---|
| Worker, schema, tools, OAuth, Team tab | Built. |
| Tested locally (workerd + local D1/KV, real OAuth flow, official MCP SDK client, real browser for the Team tab) | **Yes.** 71 backend checks + 4 persistence-after-restart checks + 36 Team-tab checks pass. |
| **Deployed to Cloudflare** | **No.** The build environment had no Cloudflare credentials or network route to Cloudflare, so there is no live URL yet. `https://<worker>.<subdomain>.workers.dev/mcp` is the *form* of the endpoint, not a working address. |
| **ChatGPT connector working** | **Not verified.** No external connection test has been run. Nothing here should be read as "ChatGPT can connect". A checklist is at the bottom. |
| Claude connector working | Not verified externally either (same reason). The in-browser Team tab was tested against the local Worker through a stand-in for the page's `mcp` capability, not through claude.ai. |
| Embedded OpenAI agent | Tested against a **mock** OpenAI server only. No real OpenAI call has been made. |
| NTree / NTN | Stored as opaque tagged resources. No format-aware handling yet (needs real example files). |

## Deploy (about ten minutes)

Needs Node 20+ and a Cloudflare account.

```bash
cd workspace && npm install
npx wrangler login
npx wrangler d1 create kitbash-workspace          # copy the database_id into wrangler.jsonc
npx wrangler kv namespace create OAUTH_KV         # copy the id into wrangler.jsonc
npx wrangler d1 migrations apply kitbash-workspace --remote
npx wrangler secret put OWNER_SECRET              # your owner key: 12+ random characters
npx wrangler secret put OPENAI_API_KEY            # optional, for the embedded OpenAI agent
# set OPENAI_MODEL in wrangler.jsonc "vars" to a model your key can call (optional)
npx wrangler deploy
curl https://<your-worker>.workers.dev/health     # expect {"ok":true,"owner_secret_configured":true,...}
```

MCP endpoint: `https://<your-worker>.workers.dev/mcp`. Discovery documents are at `/.well-known/oauth-authorization-server` and `/.well-known/oauth-protected-resource/mcp`. Clients register themselves (dynamic client registration).

**Then verify authentication yourself** (this is the deployed-endpoint check that could not be run here):

```bash
curl -i -X POST https://<your-worker>.workers.dev/mcp -H 'content-type: application/json' -d '{}'   # expect 401 + WWW-Authenticate
BASE=https://<your-worker>.workers.dev OWNER_KEY=<your key> node test/e2e.mjs                       # the whole scenario against the live Worker
```

`test/e2e.mjs` runs the OAuth flow, persistence, revisions, conflicts, handoff, approvals and scope checks against any URL. It expects a fresh database and starts a mock OpenAI server on port 8899, so point `OPENAI_BASE_URL` at it or ignore the embedded-agent section.

## Connect the agents

**Claude / the Team tab.** In claude.ai → Settings → Connectors, add a custom connector named exactly **Kitbash Workspace** with the `/mcp` URL. On the approval page pick **Claude**, leave read and write ticked, and enter your owner key. Reload Kitbash, open **Team**, type the owner key at the top. (The name must match because the page declares that connector name. Whether your claude.ai plan allows custom connectors is something to confirm.)

**ChatGPT.** Add the same URL as a custom connector in ChatGPT's settings. OpenAI's documentation says custom MCP connectors need OAuth (static tokens are not accepted) and that full write support is a beta on some plans; whether your plan can add one, and whether it can write, is **unverified**. On the approval page pick **ChatGPT**. If ChatGPT only allows read access, untick write: the connection then sees only read tools, plus `search` and `fetch`, which ChatGPT's read-only mode looks for.

**Embedded OpenAI agent.** No connector. Set `OPENAI_API_KEY` (secret) and `OPENAI_MODEL`, then in Team assign a task to the OpenAI agent and press *Run OpenAI agent* (or address it in Chat). It runs inside the Worker as its own identity. **It is not the ChatGPT app and has no memory of your ChatGPT conversations.** Its context is the workspace only: `project/BRIEF.md`, the file list, the last 20 messages and its task's files. Put what it should know in `project/BRIEF.md`.

## What an agent can and cannot do

Identity is fixed when you approve the connection (the approval page asks which agent it is). It is stored inside the access token; no tool argument can change it, so an agent cannot post as another agent.

| Action | Read-only connection | Read+write connection | Needs owner key |
|---|---|---|---|
| Read files, history, tasks, messages, approvals, checkpoints, audit log, search/fetch | yes | yes | no |
| Post messages (sender is always the connection's identity) | no | yes | no |
| Create, update, hand off tasks | no | yes (own tasks; owner may do any) | no |
| Create a file | no | yes (becomes its owner) | no |
| Edit an existing file | no | only if it owns it or holds a lease on it | no |
| Lease a file | no | files it owns, or files listed on a task assigned to it that you or the file's owner created | no |
| Change someone else's file | no | **propose only** — nothing changes until you approve | approve: yes |
| Delete a file / restore a checkpoint | no | **request only** | approve: yes |
| Approve or reject, change file owner, register or disable agents, run the OpenAI agent | no | no | yes, every call |
| Create a checkpoint | no | yes (with owner key when you do it) | optional |

Enforced by the server, not by the prompt:

- **Every file write carries `base_rev`.** 0 creates; otherwise it must be the revision last read. A stale value returns `conflict` and changes nothing (also guarded by a primary key on `(path, rev)` inside an atomic batch, so two racing writes cannot both win).
- **Leases** are time-limited and move with a task on handoff (only the assignee or you can hand off). Finishing or cancelling a task releases them.
- **Deletes are tombstones** and every revision stays readable. Restoring a checkpoint creates new revisions; it never removes history.
- **Approvals go stale** if the file changed after the request was made.
- **Disabling an agent** blocks its existing tokens immediately and drops its leases.
- **Audit log** records the acting identity and the connection it came through.

### Owner key: how it works and its limits

One passphrase (`OWNER_SECRET`) authorises the approval page and every owner-only action. Comparison is timing-safe and ten wrong attempts in ten minutes lock it out. Honest tradeoffs of this simple design: the Team tab holds the key in the page's session storage and sends it as a tool argument, so it passes through claude.ai's connector layer; an agent must never be given it (the Team tab's in-page Claude never receives it, and its tool wrapper strips any `owner_key` the model tries to pass); and messages in the workspace are not private, since every agent can read all of them. Rotate it with `wrangler secret put OWNER_SECRET` if you think it leaked; existing agent connections keep working, and owner actions need the new key.

## Files and NTree / NTN

Each file has a path, format tag, encoding (`utf8` or `base64`), free-form `meta`, SHA-256 of the original bytes, size in bytes, owner and full revision history. Import in Team → Files stores the file exactly (BOM and line endings kept; binary as base64) under `imports/…` with the tag you type (`ntree/manifest`, `ntn/config`, …). Nothing parses or rewrites those formats. Adapters for NTree manifests, skills and provenance, or for NTN launch configs, need real examples; the tag and metadata fields are where they will hook in.

Kitbash parts can be shared from Team → Files as `parts/<id>.json` (`kitbash/part`).

## Tools (29)

Read: `whoami`, `list_agents`, `list_files`, `read_file`, `file_history`, `list_tasks`, `get_task`, `get_messages`, `list_approvals`, `list_checkpoints`, `audit_log`, `search`, `fetch`.
Write scope: `post_message`, `create_task`, `update_task`, `handoff_task`, `claim_file`, `release_file`, `write_file`, `propose_change`, `request_delete`, `request_restore`, `create_checkpoint`.
Owner key required: `decide_approval`, `assign_owner`, `register_agent`, `set_agent_enabled`, `run_agent`.
(Most write tools also accept an optional `owner_key`, which the Team tab uses so your own actions are recorded as `owner`.)

## What was verified locally

Run `./test/run-local.sh` (backend) and `./test/run-ui.sh` (Team tab). Both start `wrangler dev --local` on a fresh local D1.

- Auth: no token → 401 with discovery pointer; discovery documents; dynamic registration; PKCE; consent screen needs the owner key; replayed authorisation code rejected and its token revoked; owner-key lockout.
- Scopes: a read-only token is offered no write tools; sender and actor arguments are ignored; forged handoff/system messages rejected.
- Persistence: everything above survives a Worker restart (same OAuth token, same revisions, hashes, owners, messages, tasks).
- Revisions: create, update, stale write → `conflict`, non-owner → `not_owner`, leased → `locked`, path traversal rejected, byte-exact text and base64 round-trip with correct hash.
- Handoff: claude → chatgpt → back, leases move, self-authorisation blocked, log shows sender and note.
- Approvals: proposal, delete, restore; stale detection; blocked without the owner key.
- Embedded agent against a mock: edited its authorised file, rejected on an unauthorised write, created its own file, handed the task to Claude.
- Team tab (real browser, bridge to the real local Worker): imports keep bytes and tags; re-import makes rev 2; chat to Claude, OpenAI agent, both in sequence and ChatGPT inbox; an impersonation attempt from in-page Claude posts as Claude; task handoff and *Run OpenAI agent*; approvals need the key; agent disable/enable/register; checkpoints; degraded states when the connector is missing.

## Before you call it working: external connection checklist

1. `/health` on the deployed URL returns `owner_secret_configured: true`.
2. `curl -i -X POST …/mcp` returns 401 with a `WWW-Authenticate` header naming the resource metadata.
3. `node test/e2e.mjs` against the deployed URL passes.
4. Add the connector in claude.ai; approve as Claude; in Kitbash → Team the chip reads *Connected as Claude*.
5. Add the connector in ChatGPT; note exactly what the settings screen allows (read-only, read/write, or not at all for your plan).
6. In ChatGPT, ask it to call `whoami` (it should report identity `chatgpt`), then `list_files`, then post a message; confirm the message shows in Team as coming from ChatGPT.
7. If write is allowed: ask ChatGPT to `write_file` a new file, then edit it with a stale `base_rev` and confirm the conflict.
8. Only when 4–7 pass is the ChatGPT connector verified. Until then it is untested.

## Not done yet

Parallel collaboration (only sequential handoffs), live updates in the Team tab (it refreshes on actions and on the Refresh button), a UI for viewing full file history and restoring from a checkpoint (the tools exist; the Team tab only creates checkpoints), notifications when an agent is waiting, multi-user owners, and format-aware NTree/NTN adapters.
